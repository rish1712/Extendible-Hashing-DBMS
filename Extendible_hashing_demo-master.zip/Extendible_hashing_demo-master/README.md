# Extendible_hashing_demo
A project which gives us a demo on how extendible hashing works
# How to run
To run the file go to EH_rin.zip and run the jar file provided in it.
